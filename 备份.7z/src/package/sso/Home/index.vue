<template>
  <div>Homea</div>
</template>

<script lang="ts">export default { name: 'Home' };</script>

<script lang="ts" setup>

</script>