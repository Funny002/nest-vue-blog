<template>
  <el-form ref="formRef" class="var-adminForm" v-bind="filterForm(props)" :model="props.modelValue" @submit.native.prevent="onSubmit">
    <el-row>
      <el-col v-for="(item, key) in props.data" :key="key" v-bind="filterCol(item)">
        <slot v-if="item.type === 'slot'" :name="item.slot"/>
        <admin-form-input v-else-if="item.type === 'input'" :item="item" @change="onItemChange"/>
      </el-col>
    </el-row>
  </el-form>
</template>

<script lang="ts" setup>
import { computed, provide, ref } from 'vue';
import AdminFormInput from './AdminForm_Input.vue';
import AdminFormItem, { FormProps } from './types';
import { reWriteArray } from '@utils/object';

export interface Props extends FormProps {
  data: AdminFormItem[];
  modelValue: { [key: string]: any };
}

const formRef = ref(null);

const props = withDefaults(defineProps<Props>(), {
  data: () => [],
  modelValue: () => ({}),
});

provide('formValue', computed(() => props.modelValue));

function filterForm(props: Props) {
  return reWriteArray(props, ['rules', 'inline', 'labelPosition', 'labelWidth', 'labelSuffix', 'hideRequiredAsterisk', 'showMessage	', 'inlineMessage', 'statusIcon', 'validateOnRuleChange', 'size', 'disabled']);
}

function filterCol(item: AdminFormItem) {
  return reWriteArray(item, ['xs', 'sm', 'md', 'lg', 'xl', 'span', 'offset', 'pull', 'push']);
}


const emits = defineEmits(['submit', 'change', 'update:modelValue']);

function onSubmit(event: SubmitEvent) {
  emits('submit', event);
}

function onItemChange(name: string, value: any) {
  const target = Object.assign({...props.modelValue}, {[name]: value});
  emits('update:modelValue', target);
  emits('change', name, value);
}

function validate() {}

function validateField() {}

function resetFields() {}

function scrollToField() {}

function clearValidate() {}

defineExpose({validate, validateField, resetFields, scrollToField, clearValidate});
</script>

<style lang="scss" src="@scss/components/AdminForm.scss"/>
