import { ColSizeObject } from 'element-plus/es/components/col/src/col';
import { Component } from 'vue';

export interface FormCol extends ColSizeObject {
  xs?: ColSizeObject;
  sm?: ColSizeObject;
  md?: ColSizeObject;
  lg?: ColSizeObject;
  xl?: ColSizeObject;
}

export interface FormItem {
  prop: string;
  label?: string;
  error?: string;
  required?: boolean;
  showMessage?: boolean;
  inlineMessage?: boolean;
  labelWidth?: string | number;
  rules?: { [key: string]: any };
  size?: 'large' | 'default' | 'small';
}

export interface FormProps {
  inline?: boolean;
  disabled?: boolean;
  labelSuffix?: string;
  statusIcon?: boolean;
  showMessage?: boolean;
  inlineMessage?: boolean;
  labelWidth?: string | number;
  validateOnRuleChange?: boolean;
  hideRequiredAsterisk?: boolean;
  rules?: { [key: string]: any }[];
  size?: 'large' | 'default' | 'small';
  labelPosition?: 'left' | 'right' | 'top';
}

// === === === === === === === === === ===

export interface FormInput<T = string> {
  rows?: number;
  name?: string;
  readonly?: boolean;
  disabled?: boolean;
  autofocus?: boolean;
  clearable?: boolean;
  placeholder?: string;
  autocomplete?: string;
  showPassword?: boolean;
  showWordLimit?: boolean;
  maxlength?: string | number;
  minlength?: string | number;
  prefixIcon?: string | Component;
  suffixIcon?: string | Component;
  formatter?: (value: T) => string;
  parser?: (value: string) => string;
  size?: 'large' | 'default' | 'small';
  autosize?: boolean | { minRows?: number; maxRows: number };
}

type AdminFormItem = FormCol & FormItem & FormInput & {
  type: 'slot' | 'input'
  slot?: string;
}

export default AdminFormItem;