<template>
  <admin-form-item :item="item">
    <el-input v-model="data.value" v-bind="filterInput(item)" @input="onInput"/>
  </admin-form-item>
</template>

<script lang="ts" setup>
import AdminFormItem from './AdminForm_Item.vue';
import { inject, reactive, ref, watch } from 'vue';
import { FormInput } from './types';
import { reWriteArray } from '@utils/object';

interface Props {
  item: FormInput & { prop: string };
}

const {item} = withDefaults(defineProps<Props>(), {
  item: () => ({prop: ''}),
});

const data = reactive({
  value: ref(''),
});

const _value = inject('formValue', ref({}));

watch(() => _value.value, value => {
  const formValue = value[item.prop];
  if (formValue !== data.value) {
    data.value = formValue;
  }
}, {deep: true, immediate: true});

function filterInput(item: FormInput) {
  return reWriteArray(item, ['rows', 'name', 'readonly', 'disabled', 'autofocus', 'clearable', 'placeholder', 'autocomplete', 'showPassword', 'showWordLimit', 'maxlength', 'minlength', 'prefixIcon', 'suffixIcon', 'formatter', 'parser', 'size', 'autosize']);
}

const emits = defineEmits(['change']);

function onInput(value: string) {
  emits('change', item.prop, value);
}
</script>
