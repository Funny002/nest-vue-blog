<template>
  <el-form-item v-bind="filterItem(item)">
    <template #label v-if="item.label">
      <slot name="label">{{ item.label }}</slot>
    </template>
    <slot/>
    <template #error v-if="item.error">
      <slot name="error">{{ item.error }}</slot>
    </template>
  </el-form-item>
</template>

<script lang="ts" setup>
import { FormItem } from './types';
import { reWriteArray } from '@utils/object';

interface Props {
  item: FormItem
}

const props = withDefaults(defineProps<Props>(), {
  item: () => ({prop: ''}),
});

function filterItem(item: FormItem) {
  return reWriteArray(item, ['prop', 'label', 'labelWidth', 'required', 'rules', 'error', 'showMessage', 'inlineMessage', 'size']);
}
</script>
