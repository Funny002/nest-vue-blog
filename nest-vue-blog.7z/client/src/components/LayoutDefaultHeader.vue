<template>
  <bilibili-banner-winter style='height: 150px' />
  <header class='var-layout__header'>
    adadasdas
  </header>
</template>

<script lang='ts' setup>
</script>

<style lang='scss' src='@scss/components/LayoutDefaultHeader.scss' />