<template>
  Admin/types
</template>