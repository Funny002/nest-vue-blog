<template>
  <div class="var-search">
    <admin-form :data="form.data" v-model="form.value"/>
    <span style="margin: 0 auto;"></span>
    <div class="var-search__btn">
      <el-button type="primary" :icon="Search">查询</el-button>
      <el-button type="primary" :icon="CirclePlus">新增</el-button>
    </div>
  </div>
  <div class="">
    <el-table>
      <el-table-column label="1"></el-table-column>
      <el-table-column label="2"></el-table-column>
      <el-table-column label="3"></el-table-column>
      <el-table-column label="4"></el-table-column>
      <el-table-column label="5"></el-table-column>
      <el-table-column label="6"></el-table-column>
    </el-table>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref } from 'vue';
import AdminFormItem from '../../components/AdminForm/types';
import { CirclePlus, Search } from '@element-plus/icons-vue';

const form = reactive({
  data: ref<AdminFormItem[]>([
    {type: 'input', prop: 'asdaa', clearable: true, placeholder: '标签'},
  ]),
  value: ref<{ [key: string]: any }>({}),
});

const test = reactive({
  keys: ref(''),
  value: ref(''),
});

function onClick() {
  form.value[test.keys] = test.value;
}
</script>

<!--<style lang="scss" src="@scss/"></style>-->
