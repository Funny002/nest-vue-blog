<template>
  Admin/image
</template>