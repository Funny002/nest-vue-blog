<template>
  <div class=''>内容</div>
</template>

<script lang='ts' setup>

</script>