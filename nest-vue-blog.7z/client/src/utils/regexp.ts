export const emailReg = /^(\w+)@(\w+)\.(\w+)$/;

export const phoneReg = /^(1[3456789]\d{9})$/;
